
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectTest {

	public static void main(String[] args) {
	
		try {
			System.out.println("Registering Driver...");
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver registered..");
			
			System.out.println("Trying to connect to the db..");
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb");
			 System.out.println("Conected to the DB: "+conn);
			
			 System.out.println("Tryin to make a statement: ");
			Statement statement =conn.createStatement();
			 System.out.println("statement created: "+statement);
			 
			 System.out.println("Trying to execute the statement");
			 ResultSet rs = statement.executeQuery("SELECT * FROM EMPLOYEE");
			 System.out.println("Statement executed, got he result");
			 
			 while(rs.next()) {
				 int empno = rs.getInt(1);
				 String ename = rs.getString(2);
				 int sal =rs.getInt(3);
				 System.out.println("EMP NO    :"+empno);
				 System.out.println("EMP NAME  :"+ename);
				 System.out.println("EMP SAL   :"+sal);
				 System.out.println("----------------------");
			 }
			 rs.close();
			 statement.close();
			 conn.close();
		}
		catch (SQLException e) {
			
		e.printStackTrace();
				 
		}

	}

}
