
public class StudentAlreadyExistsException extends Exception {
	StudentAlreadyExistsException(String msg){
		super(msg);
	}
}
