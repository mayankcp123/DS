public class InheritanceTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Academics acad = new Academics("Study", "great", 'A');


		acad.printAcademics();
		System.out.println("-----------");
		
		
		Btech Obj1 = new Btech("Study", "Good", 'A', "Electrical Engineering", "GTD", 8);
		
		Obj1.printBtech();

		
		System.out.println("-----------");
		
		EnggColleges engg = new EnggColleges("Study", "Nice", 'A', "Electrical Engineering", "GTD",8, "MNIT Jaipur", 3000, 85.5f);
		engg.printEnggColleges();
		System.out.println("-----------");
	}
}
class Academics
	{
	String studyOrSports;
	 String scope;
	 char grade;
		public Academics(String studyOrSports,String scope,char grade) 
		{
			super();
			this.studyOrSports = studyOrSports;
			this.scope =scope;
			this.grade = grade;
		}

		void printAcademics() 
		{
			System.out.println("Qualification : "+studyOrSports);
			System.out.println("what is the scope    : "+scope);
			System.out.println("GRADE   : "+grade);
		}
}
	class Btech extends Academics
	{
	String branch;
	String whatToStudy;
	int sem;

	public Btech(String studyOrSports, String scope, char grade, String branch, String whatToStudy, int sem) 
	{
		super(studyOrSports, scope, grade);
		this.branch = branch;
		this.whatToStudy = whatToStudy;
		this.sem = sem;
	}
	
		void printBtech() 
		{
			super.printAcademics();
			System.out.println("branch : "+branch);
			System.out.println("whatToStudy    : "+whatToStudy);
			System.out.println("sem  : "+sem);
		}
	}
	class EnggColleges extends Btech
		{
		String collegeName;
		int studentCapacity;
		float percentagePlacement;
		public EnggColleges(String studyOrSports, String scope, char grade, String branch, String whatToStudy, int sem,
				String collegeName, int studentCapacity, float percentagePlacement) {
			super(studyOrSports, scope, grade, branch, whatToStudy, sem);
			this.collegeName = collegeName;
			this.studentCapacity = studentCapacity;
			this.percentagePlacement = percentagePlacement;
		}
		
		
			void printEnggColleges() 
			{
				super.printBtech();
				System.out.println("collegeName : "+collegeName);
				System.out.println("studentCapacity    : "+studentCapacity);
				System.out.println("percentage of Placement  : "+percentagePlacement);
			}
	
		}
