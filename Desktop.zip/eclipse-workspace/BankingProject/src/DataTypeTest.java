
public class DataTypeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//-128 0 127
		byte b=28;
		System.out.println("b is "+b);
		System.out.println("min value for a byte : "+Byte.MIN_VALUE);
		System.out.println("max value for a byte : "+Byte.MAX_VALUE);
		System.out.println("size of byte variable : "+Byte.SIZE+"bits");
		System.out.println("-----------------");
		
		short s=228;
		System.out.println("s is "+s);
		System.out.println("min value for a short : "+Short.MIN_VALUE);
		System.out.println("max value for a short : "+Short.MAX_VALUE);
		System.out.println("size of short variable : "+Short.SIZE+"bits");
		
		int i=12328;
		System.out.println("i is "+i);
		System.out.println("min value for a int : "+Integer.MIN_VALUE);
		System.out.println("max value for a int : "+Integer.MAX_VALUE);
		System.out.println("size of int variable : "+Integer.SIZE+"bits");
		
		long l=1324545368;
		System.out.println("l is "+l);
		System.out.println("min value for a long : "+Long.MIN_VALUE);
		System.out.println("max value for a long : "+Long.MAX_VALUE);
		System.out.println("size of long variable : "+Long.SIZE+"bits");
		
		float f=58768678436988644.6746784637864856f;
		System.out.println("f is "+f);
		System.out.println("min value for a float : "+Float.MIN_VALUE);
		System.out.println("max value for a float : "+Float.MAX_VALUE);
		System.out.println("size of float variable : "+Float.SIZE+"bits");
				
		double d=587647866.7976746;
		System.out.println("d is "+d);
		System.out.println("min value for a double : "+Double.MIN_VALUE);
		System.out.println("max value for a double : "+Double.MAX_VALUE);
		System.out.println("size of double variable : "+Double.SIZE+"bits");
		
		char c='A';
		System.out.println("c is "+c);
		System.out.println("min value for a char : "+Character.MIN_VALUE);
		System.out.println("max value for a char : "+Character.MAX_VALUE);
		System.out.println("size of char variable : "+Character.SIZE +"bits");
	}

}
