
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FileCreationTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("Trying to create a file.");

			FileOutputStream fout = new FileOutputStream("C:/Users/MSR35/Desktop/not.txt",true);
			System.out.println("File is created.");

			Scanner scan = new Scanner(System.in);
			System.out.println("Enter your data");
			String str = scan.nextLine();

			// String str1 = "This is the Data";
			System.out.println("Got the string data.");

			byte byteArray[] = str.getBytes();
			System.out.println("Converted the string Array to byte array.");

			fout.write(byteArray);
			System.out.println("byte array is written to the file..");

			fout.close();
			System.out.println("File is closed..");
		}

		catch (IOException e) {

			System.out.println("Problem1 " + e);
		}
	}
}
