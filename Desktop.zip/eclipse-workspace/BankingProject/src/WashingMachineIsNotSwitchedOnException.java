
import com.ds.exceptions;
public class WashingMachineIsNotSwitchedOnException {

	public static void main(String[] args) {
		System.out.println("WashingMachineIsNotSwitchedOnException");

	}

}
