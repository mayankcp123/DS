import com.ds.exceptions.WashingMachineIsNotSwitchedOnException;

public class CarRunTest {
	public static void main(String[] args) {
		
	}
}
class Computer
{
boolean current;
	
	Computer() 	{
		System.out.println("Computer is created....but is"
				+ " the current availabel to it..");
	}
	void switchOn() {
		if(current==false) {
			current = true;
		}
		System.out.println("Computer is turned on....");
	}

	void compWork() throws SwitchNotOnException()
	{
		if(current == false ) {
			SwitchNotOnException SwitchNotOnEx = new SwitchNotOnException("The Computer is not yet switched on.....");
			throw SwitchNotOnEx;
		}

		System.out.println("Program started....");
		wash();
		System.out.println("Program finished...");
	}
	
}
class SwitchNotOnException
{
	
}