
public class NestedClassAssignmment {
	public static void main(String[] args) {

		
	
	}
}
