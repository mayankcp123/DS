
public class InterthreadCommunication {
	public static void main(String[] args) {
		
		Cricket food = new Cricket("Game"); //eat(), serve()
		
		Eater e = new Eater(food); // invokes eat()
		Server s = new Server(food); // invokes serve()
		
		s.start(); //run() - serve() - sequence???
		e.start(); //run() - eat() -  sequence???
	}
}
interface Bowling
{
	void bowl();
}
interface Batting
{
	void bat();
}

class Cricket implements Bowling, Batting
{
	String name;
	boolean ballbowled; // default false
	
	Cricket(String item) {
		name = item;
	}
	
	//it is possible that multiple threads can invoke this method
	//so how do we allow only one thread to invoke this method???
	
	public synchronized void eat() { // Eater thread would be calling this
		if(ballbowled==false) {
			System.out.println("Bat()  : Waiting for the bowler to bowl the ball...");
			try {
				wait(); //waits till being notified / while this thread is awaiting, other thread would 
				//get a chance to run
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//the below line would execute if the wait() is over..
		System.out.println("bat()  : Batsman is batting..."+name);
	}
	
	
	public synchronized void serve() { // Server thread would be calling this
		if(ballbowled==false) {
			System.out.println("bowl() : Ball is being bowled....");
			ballbowled=true;
			notify(); //wake up the waiting thread
		}
	}

	@Override
	public void bat() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bowl() {
		// TODO Auto-generated method stub
		
	}
}

class Eater extends Thread 
{	
	Cricket khelRef;
	
	Eater(Cricket fi) {
		khelRef = fi;
	}
	
	public void run() {
		khelRef.eat();
	}
}
class Server extends Thread
{
	Cricket khelRef;
	
	Server(Cricket fi) {
		khelRef = fi;
	}
	public void run() {
		khelRef.serve();
	}
}

/*

		  Object
		  | wait(), notify()
		  --------------------
		  |					|
		  |  Runnable		|
		  |  |				FoodItem
		  Thread
 	        |       
     	+-----------+  
	    |			|  
	 Eater		   Server


*/