
public class StaticTest {

	public static void main(String[] args) {
		
		

	}

}
class birth
{
	
}
class study extends birth
{
	
}
class engineer extends study
{
	
}
class job extends engineer
{
	
}
final class entrepreneur extends job
{
	
}
//-----------------------------------------------------------
class GullyCricket
{
	
}
class ClubCricket extends GullyCricket
{
	
}
class RanjiCricket extends ClubCricket
{
	
}
class Under19 extends RanjiCricket
{
	
}
final class MenInBlue extends RanjiCricket
{
	
}
//------------------------------------------------------------
