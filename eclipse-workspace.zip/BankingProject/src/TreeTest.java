import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;

public class TreeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Adding the elements");

		ChemicalElement ce1 = new ChemicalElement(1, "Hydrogen","H",2f);
		ChemicalElement ce2 = new ChemicalElement(10, "Neon","Ne",20f);
		ChemicalElement ce3 = new ChemicalElement(7, "Nitrogen","N",14f);
		ChemicalElement ce4 = new ChemicalElement(27, "Cobalt","Co",58.93f);
		ChemicalElement ce5 = new ChemicalElement(78, "Platinum","Pt",195.07f);

		
		
		
		System.out.println("Creating Periodic Table..");

		TreeSet<ChemicalElement> periodicTable = new TreeSet<ChemicalElement>();
		
		
	
		System.out.println("Adding the 1 elemnt");
		periodicTable.add(ce1);
	
		System.out.println("Adding the 2 elemnt");
		periodicTable.add(ce2);
		
		System.out.println("Adding the 3 elemnt");
		periodicTable.add(ce3);
		
		System.out.println("Adding the 4 elemnt");
		periodicTable.add(ce4);
		
		System.out.println("Adding the 5 elemnt");
		periodicTable.add(ce5);
		
		System.out.println("Elements are added..");
		
		System.out.println("--> Now Iterating Over the container <---");
		Iterator<ChemicalElement> setIterator = periodicTable.iterator();
	
		while(setIterator.hasNext())
		{
			ChemicalElement theElement = setIterator.next();
			System.out.println("The Element: "+theElement);
			System.out.println("-------------------");
		}
		System.out.println("============");
		
		for (ChemicalElement theElement : periodicTable) {
			System.out.println("The Element : "+theElement);
			System.out.println("-------------------");
		}
	}
}
	

class ChemicalElement implements Comparable<ChemicalElement>
{
	int atomicNumber;
	String elementName;
	String symbol;
	float atomicWt;
	public ChemicalElement(int atomicNumber, String elementName, String symbol, float atomicWt) {
		super();
		this.atomicNumber = atomicNumber;
		this.elementName = elementName;
		this.symbol = symbol;
		this.atomicWt = atomicWt;
	}
	
	@Override
	public String toString() {
		return "ChemicalElement [atomicNumber=" + atomicNumber + ", elementName=" + elementName + ", symbol=" + symbol
				+ ", atomicWt=" + atomicWt + "]";
	}
	public int compareTo(ChemicalElement o){
		System.out.println("Comparing "+atomicNumber + " with "+o.atomicNumber);
		return Integer.compare(atomicNumber, o.atomicNumber);
	}
	
}