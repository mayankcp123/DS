/*
 * Abstract Class = instance cannot be created
 * 
 * but a ref to it can be created
 * 
 */
public class AbstractTest {
	public static void main(String[] args) {
		
		
		//	GeometricalShape gs ;
			
			Circle2 c  = new Circle2(7);
		
			Rectangle rect = new Rectangle(3,4);
			Square sq= new Square(4);
			
			Hexagon hex = new Hexagon();
			
			c.draw();
			c.calcArea();
			c.calcPerimeter();
			rect.draw();
			rect.calcArea();
			rect.calcPerimeter();
			hex.draw();
			sq.draw();
			sq.calcPerimeter();
			sq.calcArea();
		
	}
}
//abstract = incomplete = partial
//Vishhal
abstract class GeometricalShape // 
{
	abstract void draw(); //no-body - partial - incomplete 
	abstract void calcArea();
	abstract void calcPerimeter();
}

//Shital
 class Hexagon extends GeometricalShape
{
	void draw() {
		System.out.println("Drawing a hexagon..");
	}

	@Override
	void calcArea() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void calcPerimeter() {
		// TODO Auto-generated method stub
		
	}
}

class Circle2 extends GeometricalShape
{
	float pi=22/7f;
	int r;
	
	
	public Circle2(int r) {
		super();
		this.r = r;
	}

	void draw() {
		System.out.println("Drawing a Circle...");
	}

	@Override
	void calcArea() {
		System.out.println("the area of the circle..."+(pi*r*r));
		
	}

	@Override
	void calcPerimeter() {
		System.out.println("the circumference of the circle..."+2*pi*r);
		
	}
}
class Square extends GeometricalShape
{
	int side;

	public Square(int side) {
		super();
		this.side = side;
	}

	void draw() {
		System.out.println("Drawing a sqaure....");
	}

	@Override
	void calcArea() {
		System.out.println("Calculating the area of the square..."+(side*side));
		
	}

	@Override
	void calcPerimeter() {
		System.out.println("Calculating the perimeter of the square..."+(4*side));
		
	}
	
}

class Rectangle extends Square //isA
{
	int side2;
	/*
	void draw() {
		System.out.println("Drawing...a Rectangle...");
	}*/

	public Rectangle(int side, int side2) {
		super(side);
		this.side2 = side2;
	}
	void calcPerimeter() {
		System.out.println("Calculating the perimeter of the rectangle..."+2*(side2*+side));
		
	}
	void calcArea() {
		System.out.println("Calculating the area of the rectangle..."+side2*side);
		
	}
}



	class Doctor
	{
		void diagnose() { //1. exclusive
		
		}
		void prescribe() { //1. exclusive
			
		}
	}

	class Surgeon extends Doctor
	{
		// now it is 2. inherited here 
		
		void doSurgery() //1. exclusive
		{
			
		}
		void diagnose() { //2. overriding
			
		}
		//3. inherited - prescribe()
	}
	class HeartSurgeon extends Surgeon
	{
		void doHeartSurgery() { 
			
		}
	}

	
	
	/*
	 * 1. exclusive
	 * 2. inherited
	 * 3. overidding
	 * 4. implemented - abstract classes/interfaces
	 */
	
	
abstract class MusicalInstrument
{
	abstract void play();
}

abstract class StringBasedMusicalInstrument extends MusicalInstrument
{
	abstract void tuneStrings();
}

class Guitar extends StringBasedMusicalInstrument
{
	void tuneStrings() {
		
	}
	void play() {
		
	}
}
class ElectronicGuitar extends Guitar
{
	
}
	