
public class ConstructorTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hospital h1=new Hospital("Ramesh",10,11);
		h1.dateOfAdm(15, "July", 2022);
		h1.dateOfDischarge(25,"July", 2022);
		Hospital h2=new Hospital("Vishal",06,10);
		h2.dateOfAdm(15, "July", 2022);
		h2.dateOfDischarge(24,"July", 2022);
	}

}
class Hospital{
	private String patientName;
	private int noOfTests;
	private int daysInHospital;
	
	
	
	Hospital(String a, int b, int c) {
		System.out.println("Input data of patient("+a+ " noOfTests="+b +"  Number of days In Hospital="+c+")");
		patientName= a;
		noOfTests=b;
		daysInHospital=c;
	}
	void dateOfAdm(int i,String month, int year)
	{
		System.out.println("The date of admission of "+patientName+ " is:"+i+month+year);
	}
	void dateOfDischarge(int i,String month, int year) {
		System.out.println("The date of discharge of "+patientName+  " is: "+i+month+year);
	}
	@Override
	public String toString() {
		return "Hospital [patientName=" + patientName + ", noOfTests=" + noOfTests + ", daysInHospital="
				+ daysInHospital + "]";
	}
	
	
}

