
public class StudentNotFoundException extends Exception {
	StudentNotFoundException(String msg){
		super(msg);
	}
}
