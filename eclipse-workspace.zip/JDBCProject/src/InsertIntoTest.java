import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class InsertIntoTest {

	public static void main(String[] args) throws EmployeeAlreadyExistsException {
		// TODO Auto-generated method stub
		try {
			System.out.println("Registering Driver...");
			DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver registered..");
			
			System.out.println("Trying to connect to the db..");
			Connection conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb");
			 System.out.println("Conected to the DB: "+conn);
			
			 System.out.println("Tryin to make a statement: ");
			 System.out.println("trying to make a Prepared statment");
				PreparedStatement pst = conn.prepareStatement("INSERT INTO EMPLOYEE VALUES (?,?,?);");
				System.out.println("Prepared Statement created : "+pst);
				
				Scanner scan1 = new Scanner(System.in);
				System.out.println("Enter employee number : ");
				int eno = scan1.nextInt();
				
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery("select * from employee where empno="+eno);
				
				 if (rs.next()) {
					 EmployeeAlreadyExistsException ex = new EmployeeAlreadyExistsException("This employee already exists.");
							 throw ex;
				 }
				
				Scanner scan2 = new Scanner(System.in);
				System.out.println("Enter employee name   : ");
				String ename = scan2.next();
				
				Scanner scan3 = new Scanner(System.in);
				System.out.println("Enter employee salary : ");
				int esal = scan3.nextInt();
				
				pst.setInt(1, eno);//fill up the question mark with its value
				pst.setString(2, ename);
				pst.setInt(3, esal);
			
			 System.out.println("tRYING TO EXECUTE THE PREPARED STATEMENT..");
			 int rows = pst.executeUpdate();
			 
			 System.out.println("Prepred Statement executed, inserted the records :..."+rows);
			
			 pst.close();	conn.close();
	 }
		catch (SQLException e) 
		{
			e.printStackTrace();		 
		}
	}

	private static ResultSet executeQuery(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	private static boolean next() {
		// TODO Auto-generated method stub
		return false;
	}

}
