
public class EmployeeAlreadyExistsException extends Exception {
	EmployeeAlreadyExistsException(String msg){
		super(msg);
	}
}
