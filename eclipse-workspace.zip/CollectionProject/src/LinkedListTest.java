import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;



public class LinkedListTest {
	public static void main(String[] args) {
		
		System.out.println("Creating the content..");

		PhoneContact contact1 = new PhoneContact("Vishhal", "Mumbai","8457157469","Vishhal@gmail.com");
		PhoneContact contact2 = new PhoneContact("Manoj", "Pune","8457487469","Manoj13@gmail.com");
		PhoneContact contact3 = new PhoneContact("Radhika", "Delhi","7945621584","Radhika69@gmail.com");
		PhoneContact contact4 = new PhoneContact("Jacqeline", "Jaipur","6201466584","Jacqueline78@gmail.com");
		PhoneContact contact5 = new PhoneContact("Diva", "Lucknow","7488578496","diva674@gmail.com");

		
		System.out.println("Content is Created..");
		
		System.out.println("Creating Container..");

		LinkedList<PhoneContact> phoneBook = new LinkedList<PhoneContact>();
		
		System.out.println("Container is ready..");
	
		System.out.println("Adding the 1 elemnt");
		phoneBook.add(contact1);
	
		System.out.println("Adding the 2 elemnt");
		phoneBook.add(contact2);
		
		System.out.println("Adding the 3 elemnt");
		phoneBook.add(contact3);
		
		System.out.println("Adding the 4 elemnt");
		phoneBook.add(contact4);
		
		System.out.println("Adding the 5 elemnt");
		phoneBook.add(contact5);
	
		System.out.println("--> Now Iterating Over the container <---");
		Iterator<PhoneContact> iterator = phoneBook.iterator();
	
		while(iterator.hasNext())
		{
			PhoneContact theContact = iterator.next();
			System.out.println("The Log: "+theContact);
		}
	}
}

class Contact
{
	String name;
	String city;
	public Contact(String name, String city) {
		super();
		this.name = name;
		this.city = city;
	}
	@Override
	public String toString() {
		return "Contact [name=" + name + ", city=" + city + "]";
	}
	
}

class PhoneContact extends Contact
{
	String contactNumber;
	String emailAddress;
	
	
	public PhoneContact(String name, String city, String contactNumber, String emailAddress) {
		super(name, city);
		this.contactNumber = contactNumber;
		this.emailAddress = emailAddress;
	}


	@Override
	public String toString() {
		return "PhoneContact [contactNumber=" + contactNumber + ", emailAddress=" + emailAddress + "]";
	}
	
	
}

