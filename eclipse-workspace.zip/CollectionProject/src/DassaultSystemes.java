import java.util.Scanner;

public class DassaultSystemes {

	public static void main(String[] args) {
		
		Department d1 = new Department();
		d1.setDeptID(10);
		d1.setDeptName("IT");
		d1.setDeptLocation("Pune");
		d1.setNoOfEmployees(0);
		
		System.out.println("Department ID is "+d1.getDeptID());
	
		System.out.println("Department Name is "+d1.getDeptName());

		System.out.println("The department location is "+d1.getDeptLocation());  
		
		System.out.println("The Number of employees is "+d1.getNoOfEmployees());  


	}

}
class Department
{
	private int ID;
	private String name;
	private String location;
	private int noOfEmployyes;
	public int getDeptID()
	{
		return this.ID;
	}
	public void setDeptID(int ID)
	{
		this.ID=ID;
	}
	public String getDeptName()
	{
		return this.name;
	}
	public void setDeptName(String name)
	{
		this.name=name;
	}
	public String getDeptLocation()
	{
		return this.location;
	}
	public void setDeptLocation(String location)
	{
		this.location=location;
	}
	public int getNoOfEmployees()
	{
		return this.noOfEmployyes;
	}
	public void setNoOfEmployees(int noOfEmployees)
	{
		this.noOfEmployyes=noOfEmployees;
	}
}
