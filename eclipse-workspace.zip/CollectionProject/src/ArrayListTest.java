import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;


public class ArrayListTest {
	public static void main(String[] args) {
		
		System.out.println("Content is Creating..");

		PhoneLog log1 = new PhoneLog("You missed a call", LocalDate.now(), "Missed"," Reeta");
		PhoneLog log2 = new PhoneLog("You dialed a call", LocalDate.now(), "Dialed"," Ankit");
		PhoneLog log3 = new PhoneLog("You received a call", LocalDate.now(), "Received"," Vipul");
		PhoneLog log4 = new PhoneLog("You got a sms", LocalDate.now(), "Message"," tara");
		PhoneLog log5 = new PhoneLog("You missed a call", LocalDate.now(), "Missed"," Reeta");
		
		System.out.println("Content is Created..");
		
		System.out.println("Creating Container..");

		ArrayList<PhoneLog> phoneLogList = new ArrayList<PhoneLog>();
		
		System.out.println("Container is ready..");
	
		System.out.println("Adding the 1 elemnt");
		phoneLogList.add(log1);
	
		System.out.println("Adding the 2 elemnt");
		phoneLogList.add(log2);
		
		System.out.println("Adding the 3 elemnt");
		phoneLogList.add(log3);
		
		System.out.println("Adding the 4 elemnt");
		phoneLogList.add(log4);
		
		System.out.println("Adding the 5 elemnt");
		phoneLogList.add(log5);
	
		System.out.println("--> Now Iterating Over the container <---");
		
		Iterator<PhoneLog> iterator = phoneLogList.iterator();
	
		while(iterator.hasNext())
		{
			PhoneLog thelog = iterator.next();
			System.out.println("The Log: "+thelog);
		} 
	}
}

class Log
{
	String LogMessage;
	LocalDate logTime;
	public Log(String logMessage, LocalDate logTime) {
		super();
		LogMessage = logMessage;
		this.logTime = logTime;
	}
	@Override
	public String toString() {
		return "Log [LogMessage=" + LogMessage + "]";
	}
	
	
}
class PhoneLog extends Log
{

	String y;
	String z;
	
	public PhoneLog(String logMessage, LocalDate logTime, String y, String z) {
		super(logMessage, logTime);
		this.y = y;
		this.z = z;
	}

	@Override
	public String toString() {
		return "PhoneLog [y=" + y + ", z=" + z + "]";
	}
	
}

	
	
