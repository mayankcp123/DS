import java.util.Scanner;

public class DefaultTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle rc = new Rectangle();
		rc.length();
		
	}
}

interface area{
default	public void length() {
	
	System.out.println("Enter length");
	
}
	default public void breadth() {
		 
	System.out.println("Enter width");
			
	}
//	default public int area(int x,int y) {
//		return x * y;
//	}
}
class Rectangle implements area{

	}
	
class finale{
	
}


