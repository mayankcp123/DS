package com.ds;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class CountryTest {

	CountryDAO cntDao = new CountryDAOImpl();

	
	@Test
	public void findCountryTest()
	{
	//	System.out.println("line1 testing the find country..test..");
	//	Assertions.assertTrue(100>50);
	//	System.out.println("line3 testing the find country..test..");
	
		Country theCountry = new Country();
		theCountry.setName("SriLanka");
		theCountry.setCapital("Colombo");
		theCountry.setPrimeMinister("Dinesh C");
		theCountry.setPopulation("2.17 Crores");
		theCountry.setCurrency("SLR");
		
		cntDao.saveCountry(theCountry);
	}
	
	@Test
	public void findAllCountriesTest() {
		
		List<Country> cntList = cntDao.findAllCountries();
		Assertions.assertTrue(cntList!=null);
		System.out.println("found the array...list");
		
		Assertions.assertTrue(cntList.size() > 0);
		System.out.println("arraylist is not empty...");
		
		for (Country country : cntList) {
			System.out.println(country);
		}
	}
	
}
