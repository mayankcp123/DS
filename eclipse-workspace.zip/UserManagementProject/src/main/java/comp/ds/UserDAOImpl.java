package comp.ds;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ds.Country;

/**
 * Servlet implementation class UserDAOImpl
 */
@WebServlet("/UserDAOImpl")
public class UserDAOImpl extends HttpServlet implements UserDAO {
	private static final long serialVersionUID = 1L;
	Connection conn; //global ref
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserDAOImpl() {
        super();
        System.out.println("FindCountryFromDatabaseServlet()");   	
        try {
	      	Class.forName("com.mysql.cj.jdbc.Driver");
	      	System.out.println("Database Driver loaded....");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","Mayank@2909");
		    System.out.println("Connected to the DB : "+conn);	
			  
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	@Override
	public void saveUser(User user) {
		try {
			PreparedStatement pst = conn.prepareStatement("insert into UserData values (?,?,?,?,?)");
			pst.setString(1, user.getUsername());
			pst.setString(2, user.getPassword());
			pst.setString(3, user.getEmail());
			pst.setString(4, user.getMobNumber());
			pst.setString(5, user.getLocation());
			int row  = pst.executeUpdate();
			System.out.println("User data saved : "+row);
		}
	
	catch (SQLException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	@Override
	public User findUser(String primaryKeyUsername) {
		User theUser = null;

		try {
			Statement st = conn.createStatement();
			System.out.println("statement created.."+st);
			ResultSet rs = st.executeQuery("SELECT * FROM UserData where username0='"+primaryKeyUsername+"'");
			System.out.println("Query fired...got the result...");
			
			
			if(rs.next()) {
				theUser = new User();
				theUser.setUsername(rs.getString(1));
				theUser.setPassword (rs.getString(2));
				theUser.setEmail ( rs.getString(3));
				theUser.setMobNumber( rs.getString(4));
				theUser.setLocation ( rs.getString(5));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return theUser;
	}



	@Override
	public List<User> findAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modifyUser(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeUser(String primaryKeyUsername) {
		// TODO Auto-generated method stub
		
	}

}
