package comp.ds;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       Connection conn;
    /**
     * @see HttpServlet#HttpServlet()
     */

	
    public Register() {
        super();
    }


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 PrintWriter pw;    
	        response.setContentType("text/html");    
	        pw=response.getWriter();    
		            
		            
		    String uname =request.getParameter("uname");    
		    String upass =request.getParameter("upass");    
		    String email =request.getParameter("email");    
		    String mobno =request.getParameter("mobno");        
		    String loc =request.getParameter("loc"); 
		            
		    try    
		     {    
		      	Class.forName("com.mysql.cj.jdbc.Driver");
		      	System.out.println("Database Driver loaded....");
				conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","Mayank@2909");
			    System.out.println("Connected to the DB : "+conn);
				    
		        String query="Insert into UserData values (?,?,?,?,?);";    
		        PreparedStatement pstmt=conn.prepareStatement(query);    
		        pstmt.setString(1, uname);    
		        pstmt.setString(2, upass);    
		        pstmt.setString(3,email);    
		        pstmt.setString(4, mobno);    
		        pstmt.setString(5, loc);    
		              
		                
		        int x=pstmt.executeUpdate();    
		               
		        if(x==1)    
		         {    
		        	pw.println("Values Inserted Successfully");    
		         }  
		        else {
		        	pw.println("Username already exists.");
		        }
		                
		        }    
		        catch(Exception e)    
		        {    
		                e.printStackTrace();    
		        }    
		            
		            
		        pw.close();    
		    }  


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		// TODO Auto-generated method stub
			doGet(request,response);
	}
	}
   


