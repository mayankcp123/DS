package comp.ds;
import java.util.List;

import comp.ds.User;

//poji - plain old java interface
public interface UserDAO { //separate the low level data access logic
	//CRUD methods 
	
	void saveUser(User user); //C
	User findUser(String primaryKeyUsername);
	List<User> findAllUsers();
	void modifyUser(User user); //U
	void removeUser(String primaryKeyUsername); //D
	
	
}