function validateUser(){
		var username = document.getElementById("uname").value
		if(username==""){
			//alert="username can not be blank";
			document.getElementById("userErr").innerHTML='username cannot be blank';
			return false;
		}
		var password= document.getElementById("upass").value
		if(password==""){
			document.getElementById("passErr").innerHTML='Password cannot be blank';
			return false;
		}
	    if (password.length < 8) {
	        alert("Your password must be at least 8 characters"); 
	        return false;
	        }
	    var reEnterPass = document.getElementById("urepass").value
	    if (reEnterPass != password){
	    	document.getElementById("repassErr").innerHTML='Password did not match';
	    	return false;
	    }
	    var email=document.getElementById("emailid").value
	    if (email=="") {
	    	document.getElementById("emailErr").innerHTML='Email can not be blank';
	    	return false;
	    }
	    var mobile=document.getElementById("mobno").value
	    if(mobile.length < 10){
		document.getElementById("mobErr").innerHTML='Mobile Number must be 10 digits';
		return false;
	}
		return true;
	}
	function clearUserErr(){document.getElementById("userErr").innerHTML="";}
	function clearPassErr(){document.getElementById("passErr").innerHTML="";}
	function clearRePassErr(){document.getElementById("repassErr").innerHTML=""}
	function clearEmailErr(){document.getElementById("emailErr").innerHTML=""}/**
 * 
 */