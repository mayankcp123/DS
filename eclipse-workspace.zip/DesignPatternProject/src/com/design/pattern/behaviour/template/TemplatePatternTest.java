package com.design.pattern.behaviour.template;
/*
 * In Template pattern, an abstract class exposes defined way(s)/template(s)
 * to execute its methods. Its subclasses can override the method 
 * implementation as per need but the invocation is to be in 
 * the same way as defined by an abstract class. 
 * This pattern comes under behavior pattern category.
 */
abstract class Game {
	   abstract void initialize();
	   abstract void startPlay();
	   abstract void endPlay();

	   //template method
	   public final void play(){ //cannot be redefined by the children

	      //initialize the game
	      initialize();
	
	      //start game
	      startPlay();

	      
	      //end game
	      endPlay();
	      

	   }
}
class Cricket extends Game {

	   @Override
	   void endPlay() {
	      System.out.println("Cricket Game Finished!");
	   }

	   @Override
	   void initialize() {
	      System.out.println("Cricket Game Initialized! Start playing.");
	   }

	   @Override
	   void startPlay() {
	      System.out.println("Cricket Game Started. Enjoy the game!");
	   }
	}

class Football extends Game {

	   @Override
	   void endPlay() {
	      System.out.println("Football Game Finished!");
	   }

	   @Override
	   void initialize() {
	      System.out.println("Football Game Initialized! Start playing.");
	   }

	   @Override
	   void startPlay() {
	      System.out.println("Football Game Started. Enjoy the game!");
	   }
	}
public class TemplatePatternTest {
	public static void main(String[] args) {
		 Game game = new Cricket();
	      game.play(); //template of "execution of sequence" is fixed in Game
	      System.out.println();
	      game = new Football();
	      game.play();
	}
}
