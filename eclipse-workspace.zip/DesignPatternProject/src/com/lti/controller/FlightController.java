package com.lti.controller;

import com.lti.model.Flight;
import com.lti.view.FlightView;

public class FlightController { //C

	private Flight flightModel; //M  chef of Pizza
	private FlightView flightView; // V  decorator cum presenter of Pizza
	
	public FlightController(Flight flightModel, FlightView flightView) {
		super();
		this.flightModel = flightModel;
		this.flightView = flightView;
	}
	
	public void setFlightNumber(int number) {
		flightModel.setFlightNumber(number);
	}
	public void setFlightName(String name) {
		flightModel.setFlightName(name);
	}
	
	public int getFlightNumber() {
		return flightModel.getFlightNumber();
	}
	
	public String getFlightName() {
		return flightModel.getFlightName();
	}
	public void updateFlightView() {
		flightView.showFlightDetails(flightModel.getFlightNumber(), flightModel.getFlightName());
	}
	public void updateFlightObjectView() {
		flightView.showFlightDetails(flightModel);
	}
}
